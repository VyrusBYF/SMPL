/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package SMPL.semantics;

import SMPL.syntax.ASTBitAnd;
import SMPL.syntax.ASTBitNot;
import SMPL.syntax.ASTBitOr;
import SMPL.syntax.ASTCase;
import SMPL.syntax.ASTComment;
import SMPL.syntax.ASTConditional;
import SMPL.syntax.ASTDefine;
import SMPL.syntax.ASTExp;
import SMPL.syntax.ASTExpAdd;
import SMPL.syntax.ASTExpAnd;
import SMPL.syntax.ASTExpChar;
import SMPL.syntax.ASTExpDiv;
import SMPL.syntax.ASTExpEqual;
import SMPL.syntax.ASTExpLRE;
import SMPL.syntax.ASTExpLess;
import SMPL.syntax.ASTExpList;
import SMPL.syntax.ASTExpLit;
import SMPL.syntax.ASTExpMRE;
import SMPL.syntax.ASTExpMod;
import SMPL.syntax.ASTExpMore;
import SMPL.syntax.ASTExpMul;
import SMPL.syntax.ASTExpNE;
import SMPL.syntax.ASTExpNot;
import SMPL.syntax.ASTExpOr;
import SMPL.syntax.ASTExpPow;
import SMPL.syntax.ASTExpSequence;
import SMPL.syntax.ASTExpStr;
import SMPL.syntax.ASTExpSub;
import SMPL.syntax.ASTExpVar;
import SMPL.syntax.ASTExpWrapper;
import SMPL.syntax.ASTLazyExp;
import SMPL.syntax.ASTLet;
import SMPL.syntax.ASTPrint;
import SMPL.syntax.ASTPrintLn;
import SMPL.syntax.ASTProcCall;
import SMPL.syntax.ASTProcDef;
import SMPL.syntax.ASTStatement;
import SMPL.syntax.ASTProgram;
import SMPL.syntax.ASTRead;
import SMPL.syntax.ASTReadInt;
import SMPL.values.PrimitiveValue;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
/**
 *
 * @author newts
 */
public class SMPLEvaluator implements Visitor {
    public enum builtIn{
        PAIR("pair",null),
        ISPAIR("pair?",null),
        SIZE("size",null),
        LIST("list",null),
        VECTOR("vector",null),
        ALLOCATE("allocate",null),
        CAR("car",null),
        CDR("cdr",null),
        INDEX("index",null),
        ISEQV("eqv?",null),
        ISEQUAL("equal?",null),
        SUBSTR("substr",null);
        
        private final String id;
        private Object closure;
        builtIn(String id,Closure c){
            this.id=id;
            this.closure=c;
        }
        
        private String id(){
            return id;
        }
      
         private void setClosure(Object c){
            this.closure=c;
        }
    }
    protected Object result = null;

    @Override
    public Object visitASTProgram(ASTProgram exp, Object arg) throws Exception {
        ArrayList<ASTExp> s = exp.getStatements().getSeq();
        Iterator iter = s.iterator();
        while(iter.hasNext()){
            ASTExp e = (ASTExp) iter.next();
            result = e.visit(this, arg);
        }
        return result;
    }

    @Override
    public Object visitASTExp(ASTExp exp, Object arg) throws Exception {
        return exp.visit(this, arg);
    }

    @Override
    public Object visitASTProcCall(ASTProcCall exp, Object arg) throws Exception {
        Environment env = (Environment) arg;
        String name = exp.getName();
        Closure fn= null;
        switch (name) {
            case "pair": 
                fn = (Closure) builtIn.PAIR.closure;
                break;
            case "pair?":
                fn = (Closure) builtIn.ISPAIR.closure;
                break;
            case "list":
                fn = (Closure) builtIn.LIST.closure;
                break;
            case "size":
                fn = (Closure) builtIn.SIZE.closure;
                break;
            case "car":
                fn = (Closure) builtIn.CAR.closure;
                break;
            case "cdr":
                fn = (Closure) builtIn.CDR.closure;
                break;
            case "eqv?":
                fn = (Closure) builtIn.ISEQV.closure;
                break;
            case "equal?":
                fn = (Closure) builtIn.ISEQUAL.closure;
                break;
            case "allocate":
                fn = (Closure) builtIn.ALLOCATE.closure;
                break;
            case "vector":
                fn = (Closure) builtIn.VECTOR.closure;
                break;
            case "substr":
                fn = (Closure) builtIn.SUBSTR.closure;
                break;
            case "index":
                fn = (Closure) builtIn.INDEX.closure;
                break;
        }
        if(fn==null){
            if(name.equals("repeat")){
                ArrayList<ASTExp> args = exp.getArgs();
                PrimitiveValue v = (PrimitiveValue) args.get(0).visit(this, arg);
                int val = v.intValue();
                Closure c = (Closure) args.get(1).visit(this, arg);
                return repeat(val,c,arg);
            }else{
                fn = env.getFn(name);
            }
        }
        ArrayList<ASTExp> args = exp.getArgs();
        ArrayList<String> params = fn.parameters;
        if(params.size()>=1){
            Iterator iter = args.iterator();
            if(params.size()==args.size()){
                ArrayList<Object> vals = new ArrayList<>();
                while(iter.hasNext()){
                    Object b = iter.next();
                    vals.add(((ASTExp) b).visit(this, arg));
                }
                String[] ids = params.toArray(new String[params.size()]);
                Object[] values = vals.toArray();
                Environment nenv = new Environment(ids,values,env);
                return fn.body.visit(this, nenv);
            }else{
                if(params.size()<args.size()){
                    if(fn.rest!=null){
                    ArrayList<Object> vals = new ArrayList<>();
                    while(iter.hasNext()){
                        ASTExp b = (ASTExp) iter.next();
                        Object n = b.visit(this, arg);
                        vals.add(n);
                    }
                    ArrayList<Object> v = new ArrayList(vals.subList(0, params.size()-1));
                    String[] ids = params.toArray(new String[params.size()]);
                    Object[] values = v.toArray();
                    Environment nenv = new Environment(ids,values,env);
                    result = fn.body.visit(this, nenv);

                    ArrayList<Object> v2 = new ArrayList(vals.subList(params.size(), vals.size()-1)); 
                    Closure rest = (Closure) env.get(fn.rest);
                    ids = rest.parameters.toArray(new String[rest.parameters.size()]);
                    nenv = new Environment(ids,v2.toArray(),env);
                    result = rest.body.visit(this, nenv);
                    return result;
                   }
                }
            }
        }else{
            if(params.size()==0 && fn.list==null){
                if(args.size()==0){
                    return fn.body.visit(this, env);
                }
            }else{
                if(params.size()==0 && fn.list!=null){
                     String[] ids = {fn.list};
                     return fn.body.visit(this, new Environment(ids,args.toArray(),env));
                }
            }
        }
        return result;
    }

    @Override
    public Object visitASTConditional(ASTConditional exp, Object arg) throws Exception{
        PrimitiveValue con = (PrimitiveValue) exp.getCondition().visit(this, arg);
        if(con.getBool()){
            ArrayList<ASTExp> seq = exp.getBody();
            Iterator iter = seq.iterator();
            while(iter.hasNext()){
                ASTExp ex = (ASTExp) iter.next();
                result = ex.visit(this, arg);
            }
            return result;
        }else{
            if(exp.getAlt()!=null){
            ArrayList<ASTExp> seq = exp.getAlt();
            Iterator iter = seq.iterator();
            while(iter.hasNext()){
                ASTExp ex = (ASTExp) iter.next();
                result = ex.visit(this, arg);
            }
            return result;
            } 
        }
        return result;
    }

    @Override
    public Object visitASTProcDef(ASTProcDef exp, Object arg) throws Exception{
        Environment env = (Environment) arg;
        ArrayList<String> param = exp.getIds();
        ASTExp body = exp.getBody();
        String rest = exp.getRest(); 
        if(rest!=null){
            result = new Closure(param,body,env,rest);
        }
        else{
            if(exp.getListID()!=null){
                result = new Closure(exp.getListID(),body,env);
            }else{
              result = new Closure(param,body,env);
            }
        }
        return result;
    }

    @Override
    public Object visitASTExpOr(ASTExpOr exp, Object arg) throws Exception{
        PrimitiveValue val1 = (PrimitiveValue) exp.getFirst().visit(this, arg);
        PrimitiveValue val2 = (PrimitiveValue) exp.getSecond().visit(this, arg);
        return val1.or(val2);
    }

    @Override
    public Object visitASTExpNot(ASTExpNot exp, Object arg) throws Exception{
        PrimitiveValue val = (PrimitiveValue) exp.getExp().visit(this, arg);
        return val.not();
    }

    @Override
    public Object visitASTExpMore(ASTExpMore exp, Object arg) throws Exception{
        PrimitiveValue val1 = (PrimitiveValue) exp.getFirst().visit(this, arg);
        PrimitiveValue Val2 = (PrimitiveValue) exp.getSecond().visit(this, arg);
        return val1.more(Val2);
    }

    @Override
    public Object visitASTExpLess(ASTExpLess exp, Object arg) throws Exception {
        PrimitiveValue val1 = (PrimitiveValue) exp.getFirst().visit(this, arg);
        PrimitiveValue Val2 = (PrimitiveValue) exp.getSecond().visit(this, arg);
        return val1.less(Val2);
    }

    @Override
    public Object visitASTExpEqual(ASTExpEqual exp, Object arg) throws Exception{
        PrimitiveValue val1 = (PrimitiveValue) exp.getFirst().visit(this, arg);
        PrimitiveValue Val2 = (PrimitiveValue) exp.getSecond().visit(this, arg);
        return val1.equal(Val2);
    }

    @Override
    public Object visitASTExpAnd(ASTExpAnd exp, Object state) throws Exception{
        PrimitiveValue val1 = (PrimitiveValue) exp.getFirst().visit(this, state);
        PrimitiveValue val2 = (PrimitiveValue) exp.getSecond().visit(this, state);
        return val1.and(val2);
    }

    @Override
    public Object visitASTDefine(ASTDefine exp, Object arg) throws Exception {
        Environment env = (Environment) arg;
        ArrayList<String> var = exp.getVar();
        Object val = exp.getValueExp().visit(this, arg);
        Iterator iter = var.iterator();
        while(iter.hasNext()){
            String name = (String) iter.next();
         switch (name) {
            case "pair": 
                if(var.size()>1){
                  ArrayList<Object>  vals = (ArrayList<Object>) val;
                  if(var.size()==vals.size()){
                    Object value = vals.get(var.indexOf(name));
                    builtIn.PAIR.setClosure(value);
                  }
                }else{
                    builtIn.PAIR.setClosure(val);
                }
                break;
            case "pair?":
                if(var.size()>1){
                  ArrayList<Object>  vals = (ArrayList<Object>) val;
                  if(var.size()==vals.size()){
                    Object value = vals.get(var.indexOf(name));
                    builtIn.ISPAIR.setClosure(value);
                  }
                }else{
                    builtIn.ISPAIR.setClosure(val);
                }
                break;
            case "list":
                if(var.size()>1){
                  ArrayList<Object>  vals = (ArrayList<Object>) val;
                  if(var.size()==vals.size()){
                    Object value = vals.get(var.indexOf(name));
                    builtIn.LIST.setClosure(value);
                  }
                }else{
                    builtIn.LIST.setClosure(val);
                }
                break;
            case "size":
                if(var.size()>1){
                  ArrayList<Object>  vals = (ArrayList<Object>) val;
                  if(var.size()==vals.size()){
                    Object value = vals.get(var.indexOf(name));
                    builtIn.SIZE.setClosure(value);
                  }
                }else{
                    builtIn.SIZE.setClosure(val);
                }
                break;
            case "car":
                if(var.size()>1){
                  ArrayList<Object>  vals = (ArrayList<Object>) val;
                  if(var.size()==vals.size()){
                    Object value = vals.get(var.indexOf(name));
                    builtIn.CAR.setClosure(value);
                  }
                }else{
                    builtIn.CAR.setClosure(val);
                }
                break;
            case "cdr":
                if(var.size()>1){
                  ArrayList<Object>  vals = (ArrayList<Object>) val;
                  if(var.size()==vals.size()){
                    Object value = vals.get(var.indexOf(name));
                    builtIn.CDR.setClosure(value);
                  }
                }else{
                    builtIn.CDR.setClosure(val);
                }
                break;
            case "eqv?":
                if(var.size()>1){
                  ArrayList<Object>  vals = (ArrayList<Object>) val;
                  if(var.size()==vals.size()){
                    Object value = vals.get(var.indexOf(name));
                    builtIn.ISEQV.setClosure(value);
                  }
                }else{
                    builtIn.ISEQV.setClosure(val);
                }
                break;
            case "equal?":
                if(var.size()>1){
                  ArrayList<Object>  vals = (ArrayList<Object>) val;
                  if(var.size()==vals.size()){
                    Object value = vals.get(var.indexOf(name));
                    builtIn.ISEQUAL.setClosure(value);
                  }
                }else{
                    builtIn.ISEQUAL.setClosure(val);
                }
                break;
            case "allocate":
                if(var.size()>1){
                  ArrayList<Object>  vals = (ArrayList<Object>) val;
                  if(var.size()==vals.size()){
                    Object value = vals.get(var.indexOf(name));
                    builtIn.ALLOCATE.setClosure(value);
                  }
                }else{
                    builtIn.ALLOCATE.setClosure(val);
                }
                break;
            case "vector":
                if(var.size()>1){
                  ArrayList<Object>  vals = (ArrayList<Object>) val;
                  if(var.size()==vals.size()){
                    Object value = vals.get(var.indexOf(name));
                    builtIn.VECTOR.setClosure(value);
                  }
                }else{
                    builtIn.VECTOR.setClosure(val);
                }
                break;
            case "substr":
                if(var.size()>1){
                  ArrayList<Object>  vals = (ArrayList<Object>) val;
                  if(var.size()==vals.size()){
                    Object value = vals.get(var.indexOf(name));
                    builtIn.SUBSTR.setClosure(value);
                  }
                }else{
                    builtIn.SUBSTR.setClosure(val);
                }
                break;
            case "index":
                if(var.size()>1){
                  ArrayList<Object>  vals = (ArrayList<Object>) val;
                  if(var.size()==vals.size()){
                    Object value = vals.get(var.indexOf(name));
                    builtIn.INDEX.setClosure(value);
                  }
                }else{
                    builtIn.INDEX.setClosure(val);
                }
                break;
        }
        }
        if(var.size()>1){
            ArrayList<Object>  vals = (ArrayList<Object>) val;
            if(var.size()==vals.size()){
                Iterator varIter = var.iterator();
                Iterator valIter = vals.iterator();
                while(varIter.hasNext()){
                    String id = (String) varIter.next();
                    Object value = valIter.next();
                    env.put(id, value);
                }
            }
        }else{
            env.put(var.get(0), val);
        }
        return result;
    }

    @Override
    public Object visitASTExpAdd(ASTExpAdd exp, Object arg) throws Exception {
        PrimitiveValue val1 = (PrimitiveValue) exp.getFirst().visit(this, arg);
        PrimitiveValue Val2 = (PrimitiveValue) exp.getSecond().visit(this, arg);
        return val1.add(Val2);
    }

    @Override
    public Object visitASTExpSub(ASTExpSub exp, Object arg) throws Exception {
        PrimitiveValue val1 = (PrimitiveValue) exp.getFirst().visit(this, arg);
        PrimitiveValue Val2 = (PrimitiveValue) exp.getSecond().visit(this, arg);
        return val1.sub(Val2);
    }

    @Override
    public Object visitASTExpMul(ASTExpMul exp, Object arg) throws Exception {
        PrimitiveValue val1 = (PrimitiveValue) exp.getFirst().visit(this, arg);
        PrimitiveValue Val2 = (PrimitiveValue) exp.getSecond().visit(this, arg);
        return val1.mul(Val2);
    }

    @Override
    public Object visitASTExpDiv(ASTExpDiv exp, Object arg) throws Exception {
        PrimitiveValue val1 = (PrimitiveValue) exp.getFirst().visit(this, arg);
        PrimitiveValue Val2 = (PrimitiveValue) exp.getSecond().visit(this, arg);
        return val1.div(Val2);
    }

    @Override
    public Object visitASTExpMod(ASTExpMod exp, Object arg) throws Exception {
        PrimitiveValue val1 = (PrimitiveValue) exp.getFirst().visit(this, arg);
        PrimitiveValue Val2 = (PrimitiveValue) exp.getSecond().visit(this, arg);
        return val1.mod(Val2);
    }

    @Override
    public Object visitASTExpLit(ASTExpLit exp, Object arg) throws Exception {
        return exp.getValue();
    }

    @Override
    public Object visitASTExpVar(ASTExpVar exp, Object arg) throws Exception {
        Environment env = (Environment) arg;
        if(exp.neg()){
            PrimitiveValue v = (PrimitiveValue) env.get(exp.getVar());
            return v.negate();
        }
        return env.get(exp.getVar());
    }

    @Override
    public Object visitASTBitNot(ASTBitNot exp, Object arg) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object visitASTBitAnd(ASTBitAnd exp, Object arg) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object visitASTBitOr(ASTBitOr exp, Object arg) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object visitASTExpNE(ASTExpNE exp, Object arg) throws Exception {
        PrimitiveValue val1 = (PrimitiveValue) exp.getFirst().visit(this, arg);
        PrimitiveValue Val2 = (PrimitiveValue) exp.getSecond().visit(this, arg);
        return val1.ne(Val2);
    }

    @Override
    public Object visitASTExpLRE(ASTExpLRE exp, Object arg) throws Exception {
        PrimitiveValue val1 = (PrimitiveValue) exp.getFirst().visit(this, arg);
        PrimitiveValue Val2 = (PrimitiveValue) exp.getSecond().visit(this, arg);
        return val1.lre(Val2);    
    }

    @Override
    public Object visitASTExpMRE(ASTExpMRE exp, Object arg) throws Exception {
        PrimitiveValue val1 = (PrimitiveValue) exp.getFirst().visit(this, arg);
        PrimitiveValue Val2 = (PrimitiveValue) exp.getSecond().visit(this, arg);
        return val1.mre(Val2);
    }

    @Override
    public Object visitASTLazyExp(ASTLazyExp exp, Object arg) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object visitASTLet(ASTLet exp, Object arg) throws Exception {
        Environment env = (Environment) arg;
        ArrayList<Binding> bindings = exp.getBindings();
        ASTExp body = exp.getBody();
        Iterator iter = bindings.iterator();
        ArrayList<String> id = new ArrayList<>();
        ArrayList<Object> val = new ArrayList<>();
        while(iter.hasNext()){
            Binding b = (Binding) iter.next();
            id.add(b.getVar());
            val.add(b.valueExp.visit(this, arg));
        }
        String[] ids = id.toArray(new String[id.size()]);
        Environment nenv = new Environment(ids,val.toArray(),env);
        return  body.visit(this, nenv);
    }

    @Override
    public Object visitASTExpSequence(ASTExpSequence exp, Object arg) throws Exception {
        ArrayList<ASTExp> seq = exp.getSeq();
        Iterator iter = seq.iterator();
        while(iter.hasNext()){
            ASTExp v = (ASTExp) iter.next();
            result = v.visit(this, arg);
        }
        return result;
    }

    @Override
    public Object visitASTExpList(ASTExpList exp, Object arg) throws Exception {
        ArrayList<ASTExp> lst = exp.getSeq();
        Iterator iter = lst.iterator();
        ArrayList<Object> res = new ArrayList<Object>();
        while(iter.hasNext()){
            ASTExp val = (ASTExp) iter.next();
            Object v = val.visit(this, arg);
            res.add(v);
        }
        return PrimitiveValue.make(res);
    }

    @Override
    public Object visitASTCase(ASTCase exp, Object arg) throws Exception {
        ArrayList<Clause> bod = exp.getBody();
        Iterator iter = bod.iterator();
        while(iter.hasNext()){
            Clause c = (Clause) iter.next();
            PrimitiveValue predicate = (PrimitiveValue) c.pred.visit(this, arg);
            if(predicate.getBool()){
                return c.valueExp.visit(this, arg);
            }
        }
        return result;
    }

    @Override
    public Object visitASTRead(ASTRead exp, Object arg) throws Exception {
        Scanner scanner = new Scanner(System.in);
        System.out.print("> ");
        String s = scanner.nextLine();
        System.out.println(s);  
        return result;
    }

    @Override
    public Object visitASTReadInt(ASTReadInt exp, Object arg) throws Exception {
        Scanner scanner = new Scanner(System.in);
        System.out.print("> ");
        Integer s = scanner.nextInt();
        System.out.println(s);  
        return result;    
    }

    @Override
    public Object visitASTPrint(ASTPrint exp, Object arg) throws Exception {
        System.out.print(exp.getSeq().visit(this, arg));
        return result;
    }

    @Override
    public Object visitASTPrintLn(ASTPrintLn exp, Object arg) throws Exception {
        System.out.println(exp.getSeq().visit(this, arg));
        return result;
    }

    @Override
    public Object visitASTComment(ASTComment exp, Object arg) throws Exception {
        String comment = exp.getVar();
        return comment;
    }

    @Override
    public Object visitASTExpStr(ASTExpStr exp, Object arg) throws Exception {
        String s = exp.getVar();
        return s;
    }

    @Override
    public Object visitASTExpChar(ASTExpChar exp, Object arg) throws Exception {
        Character c = exp.getVar();
        return c;
    }

    @Override
    public Object visitASTExpWrapper(ASTExpWrapper exp, Object arg) throws Exception {
        return exp.getValue();
    }

    @Override
    public Object visitASTExpPow(ASTExpPow exp, Object arg) throws Exception {
        PrimitiveValue val1 = (PrimitiveValue) exp.getFirst().visit(this, arg);
        PrimitiveValue Val2 = (PrimitiveValue) exp.getSecond().visit(this, arg);
        return val1.exp(Val2);
    }
    
    public Object repeat(int rep, Object closure, Object args) throws Exception {        
        Environment env = (Environment) args;
        Closure c = (Closure) closure;
        String[] id = c.parameters.toArray(new String[1]);
        ASTExp body = c.body;
        Object[] val = new Object[1];
        ArrayList<Object> res = new ArrayList<>();
        for(int i=1; i<=rep; i++){
            val[0]=PrimitiveValue.make(i);
            res.add(body.visit(this, new Environment(id,val)));            
        }
        return PrimitiveValue.make(res);
    }

}
