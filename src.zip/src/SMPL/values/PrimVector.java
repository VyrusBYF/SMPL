/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package SMPL.values;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Objects;
import java.util.Vector;

/**
 *
 * @author newts
 */
public class PrimVector extends PrimitiveValue {
    ArrayList<Object> value;
    
    public PrimVector(ArrayList<Object> val) {
        super(PrimitiveTypes.VECTOR);
        value =val;
    }
    
    @Override
    public boolean isVector() {
        return true;
    }
  
    @Override
    public ArrayList<Object> getVal() {
        return value;
    }
    
    @Override
    public PrimitiveValue add(PrimitiveValue val) throws Exception {
        if (!val.isVector()) {
            throw new Exception("Types not compatible with operation.");
        } else if (val.isInt()) {
            return new PrimInt(intValue() + val.intValue());
        } else {
            return new PrimFloat(floatValue() + val.floatValue());
        }
    }
    
    @Override
    public PrimitiveValue sub(PrimitiveValue val) throws Exception {
        if (!val.isVector()) {
            throw new Exception("Types not compatible with operation.");
        } else if (val.isInt()) {
            return new PrimInt(intValue() - val.intValue());
        } else {
            return new PrimFloat(floatValue() - val.floatValue());
        }
    }
    
    public PrimitiveValue exp(PrimitiveValue val) throws Exception {
        if (!val.isVector()) {
            throw new Exception("Types not compatible with operation.");
        } else {
            return new PrimFloat(Math.pow(floatValue(), val.floatValue()));
        }
    }
     
    @Override
    public PrimitiveValue mul(PrimitiveValue val) throws Exception {
        if (!val.isVector()) {
            throw new Exception("Types not compatible with operation.");
        } else if (val.isInt()) {
            return new PrimInt(intValue() * val.intValue());
        } else {
            return new PrimFloat(floatValue() * val.floatValue());
        }
    }
    @Override
    public PrimitiveValue div(PrimitiveValue val) throws Exception {
        if (!val.isVector()) {
            throw new Exception("Types not compatible with operation.");
        } else if (val.isInt()) {
            return new PrimInt(intValue() / val.intValue());
        } else {
            return new PrimFloat(floatValue() / val.floatValue());
        }
    }
    
    @Override
    public PrimitiveValue mod(PrimitiveValue val) throws Exception {
        if (!val.isVector()) {
            throw new Exception("Types not compatible with operation.");
        } else if (val.isInt()) {
            return new PrimInt(intValue() % val.intValue());
        } else {
            return new PrimFloat(floatValue() % val.floatValue());
        }
    }
    
    @Override
    public PrimitiveValue less(PrimitiveValue val) throws Exception {
        if (!val.isVector()) {
            throw new Exception("Types not compatible with operation.");
        }else {
            return new PrimBoolean(floatValue() < val.floatValue());
        }
    }
    @Override
    public PrimitiveValue more(PrimitiveValue val) throws Exception {
        if (! val.isVector()) {
            throw new Exception("Types not compatible with operation.");
        } else {
            return new PrimBoolean(floatValue() > val.floatValue());
        }
    }
    
    @Override
    public PrimitiveValue equal(PrimitiveValue val) throws Exception {
        if (!val.isVector()) {
            throw new Exception("Types not compatible with operation.");
        }else {
            return new PrimBoolean(floatValue() == val.floatValue());
        }
    }
    
    @Override
    public PrimitiveValue mre(PrimitiveValue val) throws Exception {
        if (!val.isVector()) {
            throw new Exception("Types not compatible with operation.");
        }else {
            return new PrimBoolean(floatValue() >= val.floatValue());
        }
    }
    
    @Override
    public PrimitiveValue lre(PrimitiveValue val) throws Exception {
        if (!val.isVector()) {
            throw new Exception("Types not compatible with operation.");
        }else {
            return new PrimBoolean(floatValue() <= val.floatValue());
        }
    }
    
    @Override
    public PrimitiveValue ne(PrimitiveValue val) throws Exception {
        if (!val.isVector()) {
            throw new Exception("Types not compatible with operation.");
        }else {
            return new PrimBoolean(floatValue() != val.floatValue());
        }
    }
    
    @Override
    public PrimitiveValue concat(PrimitiveValue val) throws Exception {
        if (!val.isVector()) {
            throw new Exception("Types not compatible with operation.");
        }else {
            value.addAll((ArrayList<Objects>)val.getVal());
            return this;
        }
    }
    
    public String toString(){
        Iterator iter = value.iterator();
        String val = "(";
        while(iter.hasNext()){
            val = val + (String) iter.next();
        }
        return val+")";
    }
}
