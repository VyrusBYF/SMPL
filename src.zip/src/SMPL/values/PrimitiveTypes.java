package SMPL.values;

public enum PrimitiveTypes {
        INTEGER,
	FLOAT,
        BOOLEAN,
        PROCEDURE,
	HEX,
	BIN;
}
