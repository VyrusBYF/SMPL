package SMPL.values;

public enum PrimitiveTypes {
        INTEGER,
	FLOAT,
        BOOLEAN,
	HEX,
        VECTOR,
        PAIR,
	BIN;
}
