/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package SMPL.syntax;

/**
 *
 * @author newts
 */
public abstract class ASTExp extends ASTNode {
    
}
