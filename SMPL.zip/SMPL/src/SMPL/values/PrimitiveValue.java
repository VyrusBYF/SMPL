package SMPL.values;


public class PrimitiveValue {
    public static final PrimitiveValue NO_VALUE = null;
    
//    private Object val;
    private PrimitiveTypes type;
    
    public static PrimitiveValue make(int val) {
        return null;
    }
    
    public static PrimitiveValue make(double val) {
        return null;
    }
    
    public static PrimitiveValue make(boolean var) {
        return null;
    }
    
    public PrimitiveValue(PrimitiveTypes type) {
        this.type = type;
    }
    
    protected void setType(PrimitiveTypes t) {
        type = t;
    }

    public PrimitiveTypes getType() {
        return type;
    }
    
    /**
     *
     * @return <code>true</code> if this value represents an integer
     */
    public boolean isInt() {
	return type == PrimitiveTypes.INTEGER;
    }
    
    /**
     *
     * @return The integer that this value represents
     * @throws FractalException if this value does not represent an integer 
     *
    public int intValue() throws FractalException {
        throw new FractalTypeException(FractalTypes.INTEGER, type);
    }

    /**
     *
     * @return <code>true</code> if this value represents a floating point number
     *
    public boolean isReal() {
	return type == FractalTypes.REAL;
    }
    
    /**
     *
     * @return The floating point number that this value represents
     * @throws FractalException if this value does not represent a real number 
     *
    public double realValue() throws FractalException {
        throw new FractalTypeException(FractalTypes.REAL, type);
    }
    
    /**
     *
     * @return <code>true</code> if this value represents either an (exact) 
     * integer or a real (inexact floating point) number.
     *
    public boolean isNumber() {
        return isInt() || isReal();
    }

    /**
     *
     * @return <code>true</code> if this value is an instance of a fractal
     *
    public boolean isFractal() {
	return type == FractalTypes.FRACTAL;
    }
    
    public Fractal fractalValue() throws FractalException {
        if (type == FractalTypes.FRACTAL) 
            return (Fractal) this;
        else
            throw new FractalTypeException(FractalTypes.FRACTAL, type);
    }
    
    /**
     * Add two values
     * @param val The value to be added to this one.
     * @return The sum of the two values
     * @throws FractalException if the types of this value and the given one are
     * incompatible.
     *
    public FractalValue add(FractalValue val) throws FractalException {
        throw new FractalTypeException(FractalTypes.REAL, val.getType());
    }
    
    /**
     * Subtract two values
     * @param val The value to be subtracted from this one.
     * @return The difference of the two values
     * @throws FractalException if the types of this value and the given one are
     * incompatible.
     *
    public FractalValue sub(FractalValue val) throws FractalException {
        throw new FractalTypeException(FractalTypes.REAL, val.getType());
    }
    
    /**
     * Multiply two values
     * @param val The value to be multiplied by this one.
     * @return The product of the two values
     * @throws FractalException if the types of this value and the given one are
     * incompatible.
     *
    public FractalValue mul(FractalValue val) throws FractalException {
        throw new FractalTypeException(FractalTypes.REAL, val.getType());
    }
    
    /**
     * Divide two values to find the quotient
     * @param val The divisor.
     * @return The quotient of this value and the given one.
     * @throws FractalException if the types of this value and the given one are
     * incompatible.
     *
    public FractalValue div(FractalValue val) throws FractalException {
        throw new FractalTypeException(FractalTypes.REAL, val.getType());
    }
    
    /**
     * Divide two values to find the remainder
     * @param val The divisor
     * @return The modulo (remainder) of this value and the given one.
     * @throws FractalException if the types of this value and the given one are
     * incompatible.
     *
    public FractalValue mod(FractalValue val) throws FractalException {
        throw new FractalTypeException(FractalTypes.REAL, val.getType());
    }
    
    public FractalValue less(FractalValue val) throws FractalException {
        throw new FractalTypeException(FractalTypes.REAL, val.getType());
    }
    
    public FractalValue more(FractalValue val) throws FractalException {
        throw new FractalTypeException(FractalTypes.REAL, val.getType());
    }
    
    public FractalValue equal(FractalValue val) throws FractalException {
        throw new FractalTypeException(FractalTypes.REAL, val.getType());
    }
    
    public FractalValue and(FractalValue val) throws FractalException {
        throw new FractalTypeException(FractalTypes.BOOLEAN, val.getType());
    }
    
    public FractalValue or(FractalValue val) throws FractalException {
        throw new FractalTypeException(FractalTypes.BOOLEAN, val.getType());
    }
    
    public FractalValue not() throws FractalException {
        return null;
    }

    public boolean isBool() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public boolean getBool() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }*/
    
}
