package SMPL.values;

public enum PrimitiveTypes {
        INTEGER,
	FLOAT,
        STRING,
        BOOLEAN,
        PROCEDURE,
	HEX,
	BIN;
}
