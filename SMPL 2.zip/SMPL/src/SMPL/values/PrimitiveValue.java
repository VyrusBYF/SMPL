package SMPL.values;

import SMPL.semantics.Closure;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Vector;
import javafx.util.Pair;


public class PrimitiveValue {
    public static final PrimitiveValue NO_VALUE = null;
    
//    private Object val;
    private PrimitiveTypes type;
    
    public static PrimitiveValue make(int val) {
        return new PrimInt(val);
    }
    
    public static PrimitiveValue make(double val) {
        return new PrimFloat(val);
    }
    
    public static PrimitiveValue make(boolean var) {
        return new PrimBoolean(var);
    }
    
    public static PrimitiveValue make(ArrayList<Object> var) {
        return new PrimVector(var);
    }
    
    public static PrimitiveValue make(Pair var) {
        return new PrimList(var);
    }
    
    public static PrimitiveValue make(Object var, Object var2) {
        return new PrimPair(var,var2);
    }
    
    public static PrimitiveValue make(Closure var) {
        return new PrimFn(var);
    }
    
    public static PrimitiveValue make(String var) throws Exception {
        if(var.startsWith("#")){
            if(var.startsWith("#b")){
                Integer b = Integer.parseInt(var.substring(2),2);
                return new PrimBin(b);
            }else{
                if(var.startsWith("#x")){
                    Integer b = Integer.parseInt(var.substring(2),16);
                    return new PrimHex(b);
                
                }else{
                    if(var.startsWith("#c")){
                        return new PrimChar( var.charAt(2));
                    }else{
                        if(var.startsWith("#u")){
                            return new PrimChar((char) Integer.parseInt(var, 16));
                        }
                    }
                }
            }
        }
        return new PrimString(var.substring(1));
    }
    
    public PrimitiveValue(PrimitiveTypes type) {
        this.type = type;
    }
    
    protected void setType(PrimitiveTypes t) {
        type = t;
    }

    public PrimitiveTypes getType() {
        return type;
    }
    
    /**
     *
     * @return <code>true</code> if this value represents an integer
     */
    public boolean isInt() {
	return type == PrimitiveTypes.INTEGER;
    }
    
    /**
     *
     * @return The integer that this value represents
     * @throws FractalException if this value does not represent an integer 
     */
    public int intValue() throws Exception {
        throw new Exception("Type Error: "+PrimitiveTypes.INTEGER+ " expected.");
    }

    /**
     *
     * @return <code>true</code> if this value represents a floating point number
     */
    public boolean isFloat() {
	return type == PrimitiveTypes.FLOAT;
    }
    
    /**
     *
     * @return The floating point number that this value represents
     * @throws FractalException if this value does not represent a floating point number 
     */
    public double floatValue() throws Exception {
        throw new Exception("Type Error: "+PrimitiveTypes.FLOAT+ " expected.");
    }
    
    /**
     *
     * @return <code>true</code> if this value represents either an (exact) 
     * integer or a real (inexact floating point) number.
     */
    public boolean isNumber() {
        return isInt() || isFloat();
    }
    
    /**
     * Add two values
     * @param val The value to be added to this one.
     * @return The sum of the two values
     * @throws FractalException if the types of this value and the given one are
     * incompatible.
     */
    public PrimitiveValue add(PrimitiveValue val) throws Exception {
        throw new Exception("Not supported yet.");
    }
    
    /**
     * Subtract two values
     * @param val The value to be subtracted from this one.
     * @return The difference of the two values
     * @throws FractalException if the types of this value and the given one are
     * incompatible.
     */
    public PrimitiveValue sub(PrimitiveValue val) throws Exception {
        throw new Exception("Not supported yet.");
    }
    
     public PrimitiveValue exp(PrimitiveValue val) throws Exception {
        throw new Exception("Not supported yet.");
    }
    
    /**
     * Multiply two values
     * @param val The value to be multiplied by this one.
     * @return The product of the two values
     * @throws FractalException if the types of this value and the given one are
     * incompatible.
     */
    public PrimitiveValue mul(PrimitiveValue val) throws Exception {
        throw new Exception("Not supported yet.");
    }
    
    /**
     * Divide two values to find the quotient
     * @param val The divisor.
     * @return The quotient of this value and the given one.
     * @throws FractalException if the types of this value and the given one are
     * incompatible.
     */
    public PrimitiveValue div(PrimitiveValue val) throws Exception {
        throw new Exception("Not supported yet.");
    }
    
    /**
     * Divide two values to find the remainder
     * @param val The divisor
     * @return The modulo (remainder) of this value and the given one.
     * @throws FractalException if the types of this value and the given one are
     * incompatible.
     */
    public PrimitiveValue mod(PrimitiveValue val) throws Exception {
        throw new Exception("Not supported yet.");
    }
    
    public PrimitiveValue less(PrimitiveValue val) throws Exception {
        throw new Exception("Not supported yet.");
    }
    
    public PrimitiveValue more(PrimitiveValue val) throws Exception {
        throw new Exception("Not supported yet.");
    }
    
    public PrimitiveValue equal(PrimitiveValue val) throws Exception {
        throw new Exception("Not supported yet.");
    }
    
    public PrimitiveValue equiv(PrimitiveValue val) throws Exception {
        throw new Exception("Not supported yet.");
    }
    
    public PrimitiveValue and(PrimitiveValue val) throws Exception {
        throw new Exception("Not supported yet.");
    }
    
    public PrimitiveValue or(PrimitiveValue val) throws Exception {
        throw new Exception("Not supported yet.");
    }
    
    public boolean isString() throws Exception {
        throw new Exception("Not supported yet.");
    }
    
    public PrimitiveValue not() throws Exception {
        throw new Exception("Not supported yet.");
    }
    
    public PrimitiveValue mre(PrimitiveValue val) throws Exception {
        throw new Exception("Not supported yet.");
    }
    
    public PrimitiveValue lre(PrimitiveValue val) throws Exception {
        throw new Exception("Not supported yet.");
    }
    
    public PrimitiveValue ne(PrimitiveValue val) throws Exception {
        throw new Exception("Not supported yet.");
    }

    public boolean isBool() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public boolean getBool() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public Object getVal() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public PrimitiveValue negate() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public boolean isVector() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public boolean isPair() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public boolean isFn() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public PrimitiveValue concat(PrimitiveValue val) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
