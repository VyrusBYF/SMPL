/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package SMPL.values;

import java.util.ArrayList;

/**
 *
 * @author newts
 */
public class PrimString extends PrimitiveValue {
    String value;
    
    public PrimString(String val) {
        super(PrimitiveTypes.STRING);
        value =val;
    }
    
    @Override
    public boolean isInt() {
        return false;
    }
    
    @Override
    public boolean isString() {
        return true;
    }
    
    @Override
    public PrimitiveValue add(PrimitiveValue val) throws Exception {
            return new PrimString(value + val.toString());
    }
     
    @Override
    public PrimitiveValue mul(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    
    @Override
    public PrimitiveValue less(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    @Override
    public PrimitiveValue more(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    
    @Override
    public PrimitiveValue equal(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    
    @Override
    public PrimitiveValue mre(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    
    @Override
    public PrimitiveValue lre(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    
    @Override
    public PrimitiveValue ne(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
        
    public String toString(){
        return value;
    }
}
