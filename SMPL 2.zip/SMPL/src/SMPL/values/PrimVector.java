/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package SMPL.values;

import SMPL.syntax.ASTExp;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Objects;
import java.util.Vector;

/**
 *
 * @author newts
 */
public class PrimVector extends PrimitiveValue {
    ArrayList<Object> value;
    
    public PrimVector(ArrayList<Object> val) {
        super(PrimitiveTypes.VECTOR);
        value = val;
    }
    
    @Override
    public boolean isVector() {
        return true;
    }
  
    @Override
    public ArrayList<Object> getVal() {
        return value;
    }
   
    
    @Override
    public PrimitiveValue add(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    
    @Override
    public PrimitiveValue sub(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    
    public PrimitiveValue exp(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
     
    @Override
    public PrimitiveValue mul(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    @Override
    public PrimitiveValue div(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    
    @Override
    public PrimitiveValue mod(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    
    @Override
    public PrimitiveValue less(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    @Override
    public PrimitiveValue more(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    
    @Override
    public PrimitiveValue equal(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    
    @Override
    public PrimitiveValue mre(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    
    @Override
    public PrimitiveValue lre(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    
    @Override
    public PrimitiveValue ne(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    
    @Override
    public PrimitiveValue concat(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    
    public int size() {
        return value.size();
    }
    
    public String toString(){
        String val = "[: ";
        for(int i=(value.size())-1; i<0;i--){
            if(i==0)
                val = val + value.get(i).toString();
            else
                val = val + ", " + value.get(i).toString();
        }
        return val+" :]";
    }
}
