/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SMPL.values;

import SMPL.semantics.Closure;

/**
 *
 * @author Owner
 */
public class PrimFn extends PrimitiveValue {
    
    Closure fn;
    
    public PrimFn(Closure procedure) {
        super(PrimitiveTypes.BOOLEAN);
        this.fn=procedure;
    }
    
    @Override
    public boolean isInt() {
        return false;
    }
    
    @Override
    public boolean isFn() {
        return true;
    }
    
    public Closure getClosure(){
        return fn;
    }
    
    @Override
    public String toString(){
        return "Procedure Object.";
    }
    
}
