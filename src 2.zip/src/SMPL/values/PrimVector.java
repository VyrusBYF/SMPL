/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package SMPL.values;

import SMPL.syntax.ASTExp;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Objects;
import java.util.Vector;

/**
 *
 * @author newts
 */
public class PrimVector extends PrimitiveValue {
    Object[] value;
    
    public PrimVector(ArrayList<Object> val) {
        super(PrimitiveTypes.VECTOR);
        value = val.toArray();
    }
    
    @Override
    public boolean isVector() {
        return true;
    }
  
    @Override
    public Object[] getVal() {
        return value;
    }
   
    
    @Override
    public PrimitiveValue add(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    
    @Override
    public PrimitiveValue sub(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    
    public PrimitiveValue exp(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
     
    @Override
    public PrimitiveValue mul(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    @Override
    public PrimitiveValue div(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    
    @Override
    public PrimitiveValue mod(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    
    @Override
    public PrimitiveValue less(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    @Override
    public PrimitiveValue more(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    
    @Override
    public PrimitiveValue equal(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    
    @Override
    public PrimitiveValue mre(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    
    @Override
    public PrimitiveValue lre(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    
    @Override
    public PrimitiveValue ne(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    
    @Override
    public PrimitiveValue concat(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    
    public int size() {
        return value.length;
    }
    
    public String toString(){
        String val = "[: ";
        for(int i=0; i<value.length;i++){
            if(i==0)
                val = val + value[i];
            else
                val = val + ", " + value[i];
        }
        return val+" :]";
    }
}
