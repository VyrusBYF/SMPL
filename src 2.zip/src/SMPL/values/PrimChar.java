/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package SMPL.values;

import java.util.ArrayList;

/**
 *
 * @author newts
 */
public class PrimChar extends PrimitiveValue {
    char value;
    
    public PrimChar(Character c) {
        super(PrimitiveTypes.CHAR);
        value =c;
    }
    
    @Override
    public boolean isInt(){
        return false;
    }
     
    @Override
    public PrimitiveValue mul(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    
    @Override
    public PrimitiveValue more(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");

    }
    
    @Override
    public PrimitiveValue equal(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");

    }
    
    @Override
    public PrimitiveValue mre(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    
    @Override
    public PrimitiveValue lre(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    
    @Override
    public PrimitiveValue ne(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    
    @Override
    public String toString(){
        return "'"+value+"'";
    }
}
