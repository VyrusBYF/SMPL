/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package SMPL.values;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Vector;
import javafx.util.Pair;

/**
 *
 * @author newts
 */
public class PrimList extends PrimitiveValue {
    Pair value;
    
    public PrimList(Pair val) {
        super(PrimitiveTypes.VECTOR);
        value =val;
    }
  
    @Override
    public Pair getVal() {
        return value;
    }
    
    @Override
    public PrimitiveValue add(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    
    @Override
    public PrimitiveValue sub(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    
    public PrimitiveValue exp(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
     
    @Override
    public PrimitiveValue mul(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    @Override
    public PrimitiveValue div(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    
    @Override
    public PrimitiveValue mod(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    
    @Override
    public PrimitiveValue less(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    @Override
    public PrimitiveValue more(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    
    @Override
    public PrimitiveValue equal(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    
    @Override
    public PrimitiveValue mre(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    
    @Override
    public PrimitiveValue lre(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    
    @Override
    public PrimitiveValue ne(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    
    @Override
    public PrimitiveValue concat(PrimitiveValue val) throws Exception {
        throw new Exception("Types not compatible with operation.");
    }
    
    public int size() throws Exception {
        throw new Exception("Operation not allowed.");
    }
    
    public String toString(){
        return "List Object";
    }
}
