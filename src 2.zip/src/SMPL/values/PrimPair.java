/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package SMPL.values;

import java.util.Collection;
import java.util.Iterator;
import javafx.util.Pair;

/**
 *
 * @author newts
 */
public class PrimPair extends PrimitiveValue {
    Pair<Object, Object> value;
    
    public PrimPair(Object val, Object val2) {
        super(PrimitiveTypes.PAIR);
        value =new Pair(val,val2);
    }
    
    @Override
    public boolean isPair() {
        return true;
    }
  
    @Override
    public Pair getVal() {
        return value;
    }
    
    @Override
    public PrimitiveValue add(PrimitiveValue val) throws Exception {
        if (!val.isPair()) {
            throw new Exception("Types not compatible with operation.");
        } else if (val.isInt()) {
            return new PrimInt(intValue() + val.intValue());
        } else {
            return new PrimFloat(floatValue() + val.floatValue());
        }
    }
    
    @Override
    public PrimitiveValue sub(PrimitiveValue val) throws Exception {
        if (!val.isPair()) {
            throw new Exception("Types not compatible with operation.");
        } else if (val.isInt()) {
            return new PrimInt(intValue() - val.intValue());
        } else {
            return new PrimFloat(floatValue() - val.floatValue());
        }
    }
    
    public PrimitiveValue exp(PrimitiveValue val) throws Exception {
        if (!val.isPair()) {
            throw new Exception("Types not compatible with operation.");
        } else {
            return new PrimFloat(Math.pow(floatValue(), val.floatValue()));
        }
    }
     
    @Override
    public PrimitiveValue mul(PrimitiveValue val) throws Exception {
        if (!val.isPair()) {
            throw new Exception("Types not compatible with operation.");
        } else if (val.isInt()) {
            return new PrimInt(intValue() * val.intValue());
        } else {
            return new PrimFloat(floatValue() * val.floatValue());
        }
    }
    @Override
    public PrimitiveValue div(PrimitiveValue val) throws Exception {
        if (!val.isPair()) {
            throw new Exception("Types not compatible with operation.");
        } else if (val.isInt()) {
            return new PrimInt(intValue() / val.intValue());
        } else {
            return new PrimFloat(floatValue() / val.floatValue());
        }
    }
    
    @Override
    public PrimitiveValue mod(PrimitiveValue val) throws Exception {
        if (!val.isPair()) {
            throw new Exception("Types not compatible with operation.");
        } else if (val.isInt()) {
            return new PrimInt(intValue() % val.intValue());
        } else {
            return new PrimFloat(floatValue() % val.floatValue());
        }
    }
    
    @Override
    public PrimitiveValue less(PrimitiveValue val) throws Exception {
        if (!val.isPair()) {
            throw new Exception("Types not compatible with operation.");
        }else {
            return new PrimBoolean(floatValue() < val.floatValue());
        }
    }
    @Override
    public PrimitiveValue more(PrimitiveValue val) throws Exception {
        if (! val.isPair()) {
            throw new Exception("Types not compatible with operation.");
        } else {
            return new PrimBoolean(floatValue() > val.floatValue());
        }
    }
    
    @Override
    public PrimitiveValue equal(PrimitiveValue val) throws Exception {
        if (!val.isPair()) {
            throw new Exception("Types not compatible with operation.");
        }else {
            return new PrimBoolean(floatValue() == val.floatValue());
        }
    }
    
    @Override
    public PrimitiveValue mre(PrimitiveValue val) throws Exception {
        if (!val.isPair()) {
            throw new Exception("Types not compatible with operation.");
        }else {
            return new PrimBoolean(floatValue() >= val.floatValue());
        }
    }
    
    @Override
    public PrimitiveValue lre(PrimitiveValue val) throws Exception {
        if (!val.isPair()) {
            throw new Exception("Types not compatible with operation.");
        }else {
            return new PrimBoolean(floatValue() <= val.floatValue());
        }
    }
    
    @Override
    public PrimitiveValue ne(PrimitiveValue val) throws Exception {
        if (!val.isPair()) {
            throw new Exception("Types not compatible with operation.");
        }else {
            return new PrimBoolean(floatValue() != val.floatValue());
        }
    }
    
    public Object car() throws Exception {
        return value.getKey();
    }
    
     public Object cdr() throws Exception {
        return value.getValue();
    }
    
    @Override
    public String toString(){
       return "" + value.getKey() + value.getValue();
    }
}
