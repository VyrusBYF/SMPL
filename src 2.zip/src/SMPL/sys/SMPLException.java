/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package SMPL.sys;

import SMPL.syntax.ASTExp;

/**
 *
 * @author newts
 */
public class SMPLException extends Exception {
    private static final long serialVersionUID = 1L;
    
    private ASTExp source;
    
    public SMPLException() {
        super();
    }
    
    public SMPLException(String message) {
        super (message);
    }
    
    public SMPLException(String message, Throwable cause) {
        super(message, cause);
    }
    
    public SMPLException(ASTExp node, String message) {
        super(message);
        source = node;
    }
    
    public SMPLException(ASTExp node, String message, Throwable cause) {
        super(message, cause);
        source = node;
    }
    
    public ASTExp getSource() {
        return source;
    }
    
    protected void setSource(ASTExp src) {
        source = src;
    }
}
